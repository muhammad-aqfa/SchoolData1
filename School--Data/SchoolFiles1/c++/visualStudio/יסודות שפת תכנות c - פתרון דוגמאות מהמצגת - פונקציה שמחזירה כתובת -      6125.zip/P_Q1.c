#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int* func(int size, int start)
{
	int *ptr, i;
	ptr = (int*)malloc(size * sizeof(int));

	if (!ptr) {
		return 0;
	}

	for (i = 0; i < size; i++, start++)
	{
		ptr[i] = start;
	}

	return ptr;
}

void main()
{
	int *dyn_arr, size, start, *p;
	printf("YO! Please enter the size of the array: ");
	scanf("%d", &size);
	printf("Please enter the start point: ");
	scanf("%d", &start);

	dyn_arr = func(size, start);

	if (dyn_arr)
		for (p = dyn_arr; p - dyn_arr < size; p++)
			printf("%d\n", *p);
}

/*
YO! Please enter the size of the array: 5
Please enter the start point: 10
10
11
12
13
14
Press any key to continue . . .
*/