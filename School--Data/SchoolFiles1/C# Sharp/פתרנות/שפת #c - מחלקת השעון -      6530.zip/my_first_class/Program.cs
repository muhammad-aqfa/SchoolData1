﻿using System;

namespace my_first_class
{
    class Program
    {
        static void Main(string[] args)
        {
            Clock c1 = new Clock(5,30);
            Console.WriteLine(c1.getTime());
        }
    }
}
