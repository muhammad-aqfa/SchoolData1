namespace my_first_class
{
    public class Clock
    {
        //תכונות
        private int minutes;
        private int hours;

        //בנאי
        public Clock(int h, int m)
        {
            Hours = h;
            Minutes = m;
        }

        //Properties
        public int Minutes
        {
            get { return minutes; }
            private set
            {
                minutes = (value > 59 && value < 0) ? 0 : value;
            }
        }

        public int Hours
        {
            get { return hours; }
            private set
            {
                hours = (value > 23 && value < 0) ? 0 : value;
            }
        }

        public string getTime()
        {
            string str = "";
            if (Hours < 10)
                str += "0" + Hours + ":";
            else
                str += Hours + ":";

            if (Minutes < 10)
                str += "0" + Minutes;
            else
                str += Minutes;

            return str;
        }



    }
}