﻿using System;

namespace student_ex
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Lior","Bnei Aish",24.7);
            Console.WriteLine(s1.GetStudentDetails());
            s1.GrowUp(4);
            Console.WriteLine(s1.GetStudentDetails());
            s1.HappyBirthday();
            Console.WriteLine(s1.GetStudentDetails());
        }
    }
}

/*

Student Name: Lior
Student Age: 24.7
Student Address: Bnei Aish

Student Name: Lior
Student Age: 28.7
Student Address: Bnei Aish

Student Name: Lior
Student Age: 29.7
Student Address: Bnei Aish

*/