namespace student_ex
{
    public class Student
    {
        private string name, address;
        private double age;

        //Properties
        public string Name { get; private set; }
        public string Address { get; private set; }
        public double Age
        {
            get { return age; }
            private set
            {
                age = (value >= 0 && value <= 120) ? value : 0;
            }
        }

        //ctor -> constructor
        public Student(string name, string address, double age)
        {
            Name = name;
            Age = age;
            Address = address;
        }

        //פונקציה שמבגרת את הסטודנט במקסימום 10 שנים 
        public void GrowUp(int years)
        {
            age += (years >= 0 && years <= 10) ? years : 0;
        }

        //פונקציה שמבגרת את הסטודנט בשנה אחת כי יש לו יום הולדת
        public void HappyBirthday()
        {
            GrowUp(1);
        }

        //פונקציה שמחזירה מחרוזת עם כל פרטי הסטודנט
        public string GetStudentDetails()
        {
            string str = "";

            str += $"Student Name: {Name}\n";
            str += $"Student Age: {Age}\n";
            str += $"Student Address: {Address}\n";

            return str;
        }

    }
}

